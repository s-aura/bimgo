const router = require('express').Router();
const transTable = require('../models/Transaction');

// type -> 0 : expense
// type -> 1 : income
router.post('/add_transaction', (req, res) => {
    const { user_id, amount, type, description, category, date } = req.body;

    // add to transaction
    console.log('getting');
    const newTransaction = new transTable({
        user_id,
        type,
        amount,
        description,
        category,
        date
    });
    newTransaction.save()
    .then(() => res.json('Transaction added!'))
})


router.options('/add_budget', (req, res) => {

})


module.exports = router;