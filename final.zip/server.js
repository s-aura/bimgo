const express = require("express");
const dbconnect = require("./dbconnect");
const userRoute = require("./routes/usersRoutes");
const transRoute = require("./routes/transRoute");
const app = express();

app.use(express.json());
app.use("/api/users", userRoute);
app.use("/api/expense", transRoute);

const port = 5000;

app.listen(port, () => console.log(`listen on port no ${port}`));
